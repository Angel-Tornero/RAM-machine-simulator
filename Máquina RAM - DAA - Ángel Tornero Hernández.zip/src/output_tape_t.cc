#include "../include/output_tape_t.h"
#include <fstream>

output_tape_t::output_tape_t(std::string fileName) {
  fileName_ = fileName;
}