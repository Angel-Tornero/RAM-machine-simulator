# Simulador de Máquina RAM

- Universidad de La Laguna
- Escuela Superior de Ingeniería y Tecnología
- Grado en Ingeniería Informática
- Diseño y Análisis de Algoritmos

## Autor

- Ángel Tornero Hernández

## Fecha

- 1 Marzo 2021