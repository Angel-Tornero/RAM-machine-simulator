#include <string>
#include <vector>

#ifndef _TAPE_
#define _TAPE_

class tape_t {

  protected:
    std::vector<int> values_;
    std::string fileName_;
  
  public:

};

#endif