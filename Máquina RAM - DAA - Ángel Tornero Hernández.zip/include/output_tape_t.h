#include "tape_t.h"

class output_tape_t: public tape_t {

  public:
    output_tape_t(std::string fileName);

};