#include <vector>

class memory_t {
  private:
    std::vector<int> register_;

};